const Test = () => {
    const errorFnc = ()=> {
        throw new Error("i am error")
    }
    return (
        <button onClick={()=>errorFnc()}>
            click test
        </button>
    )
}
export default Test